<?php

namespace Infinity\populator;

use pocketmine\block\Block;
use pocketmine\level\ChunkManager;
use pocketmine\level\generator\populator\Populator;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\utils\Random;
use Infinity\planner\VillagePlanner;
use Infinity\Structures;

class VillagePopulator extends Populator{

    public $spawnRadius        = 2000;
    public $targetVillageCount = 12;
    public $searchChunks       = 0;
    public $minLandFraction    = 0.3;
    public $maxHeightVariation = 24;
    public $logGeneration      = false;

    const WATER_IDS = [
        Block::WATER, Block::STILL_WATER,
        Block::LAVA,  Block::STILL_LAVA,
    ];

    private $spawn      = null;
    private $structuresDir;
    private $planner    = null;
    private $plugin;

    public function __construct(string $structuresDir, Structures $plugin){
        $this->structuresDir = rtrim($structuresDir, "\\/") . "/";
        $this->plugin = $plugin;
    }

    public function configure(array $options){
        if(isset($options["spawn-radius"]))         $this->spawnRadius         = (int)$options["spawn-radius"];
        if(isset($options["target-count"]))         $this->targetVillageCount  = (int)$options["target-count"];
        if(isset($options["search-chunks"]))        $this->searchChunks        = (int)$options["search-chunks"];
        if(isset($options["min-land-fraction"]))    $this->minLandFraction     = (float)$options["min-land-fraction"];
        if(isset($options["max-height-variation"])) $this->maxHeightVariation  = (int)$options["max-height-variation"];
        if(isset($options["log-generation"]))       $this->logGeneration       = (bool)$options["log-generation"];
    }

    public function populate(ChunkManager $level, $chunkX, $chunkZ, Random $random){
        $wx = ($chunkX << 4) + 8;
        $wz = ($chunkZ << 4) + 8;

        $spawn = $this->getSpawn($level);
        $dx = $wx - $spawn->x;
        $dz = $wz - $spawn->z;
        if(($dx * $dx + $dz * $dz) > $this->spawnRadius * $this->spawnRadius){
            return;
        }

        $effectiveSearch = $this->searchChunks > 0
            ? $this->searchChunks
            : (int)max(100, round(M_PI * $this->spawnRadius * $this->spawnRadius / 256.0));

        $probPerChunk = $this->targetVillageCount / max(1, $effectiveSearch);
        $hash = self::chunkHash($level->getSeed(), $chunkX, $chunkZ);
        $roll = ($hash & 0xFFFFFF) / (float)0x1000000;
        if($roll >= $probPerChunk){
            return;
        }

        $cy = self::findSurfaceY($level, $wx, $wz);
        if($cy < 0) return;

        $centerBlock = $level->getBlockIdAt($wx, $cy - 1, $wz);
        if(in_array($centerBlock, self::WATER_IDS, true)) return;

        $landCount    = 0;
        $sampleCount  = 0;
        $heights      = [];

        for($ox = -8; $ox <= 8; $ox += 4){
            for($oz = -8; $oz <= 8; $oz += 4){
                $sx = $wx + $ox;
                $sz = $wz + $oz;
                $sy = self::findSurfaceY($level, $sx, $sz);
                if($sy < 0) continue;
                $sampleCount++;
                $block = $level->getBlockIdAt($sx, $sy - 1, $sz);
                if(!in_array($block, self::WATER_IDS, true)){
                    $landCount++;
                    $heights[] = $sy;
                }
            }
        }

        if($sampleCount === 0) return;
        if(($landCount / $sampleCount) < $this->minLandFraction) return;

        if(count($heights) > 1){
            if((max($heights) - min($heights)) > $this->maxHeightVariation) return;
        }

        $villageRandom = new Random($hash);
        if($this->planner === null){
            $this->planner = new VillagePlanner($this->structuresDir);
        }
        $this->planner->generate($level, $wx, $cy, $wz, $villageRandom);
        $this->logVillage($wx, $cy, $wz);
    }

    private function getSpawn(ChunkManager $level): Vector3{
        if($this->spawn !== null) return $this->spawn;
        foreach(["getSpawnLocation", "getSpawn"] as $method){
            if(method_exists($level, $method)){
                try{
                    $s = $level->$method();
                    if($s instanceof Vector3) return $this->spawn = $s;
                }catch(\Throwable $e){}
            }
        }
        return $this->spawn = new Vector3(0, 128, 0);
    }

    private function logVillage(int $x, int $y, int $z): void{
        if(!$this->logGeneration) return;
        try{
            $server = Server::getInstance();
            if($server === null) return;
            $server->getLogger()->notice("Village generated at {$x} {$y} {$z}");
        }catch(\Throwable $e){}
    }

    public static function chunkHash($seed, int $chunkX, int $chunkZ): int{
        $h = (int)$seed;
        $h ^= ($chunkX * 0x9E3779B9);
        $h ^= ($chunkZ * 0x85EBCA77);
        $h ^= ($h >> 13);
        $h = ($h * 0xC2B2AE3D) & 0x7FFFFFFF;
        return $h;
    }

    public static function findSurfaceY(ChunkManager $level, int $x, int $z): int{
        $waterish = [
            Block::WATER, Block::STILL_WATER,
            Block::LAVA,  Block::STILL_LAVA,
        ];
        $passthrough = [
            Block::AIR, Block::LEAVES, Block::LEAVES2,
            Block::TALL_GRASS, Block::SNOW_LAYER,
            Block::LOG, Block::WOOD2,
        ];
        for($y = 127; $y > 0; --$y){
            $b = $level->getBlockIdAt($x, $y, $z);
            if(in_array($b, $passthrough, true)) continue;
            if(in_array($b, $waterish, true)) return -1;
            return $y + 1;
        }
        return -1;
    }
}
