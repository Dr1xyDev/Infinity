<?php

namespace Infinity\planner;

use pocketmine\block\Block;
use pocketmine\level\ChunkManager;
use pocketmine\utils\Random;
use Infinity\generator\FarmGenerator;
use Infinity\generator\RoadGenerator;
use Infinity\generator\WellGenerator;
use Infinity\structure\StructureLoader;

class VillagePlanner{

        const MIN_DIST_FROM_WELL = 10;

        const MAX_DIST_FROM_WELL = 28;

        const MIN_DIST_BETWEEN_STRUCTS = 10;

        const MAX_PLACEMENT_ATTEMPTS = 50;

        private static $cache = [];

        private $structuresDir;

        public function __construct(string $structuresDir){
                $this->structuresDir = rtrim($structuresDir, "\\/") . "/";
        }

        public function generate(ChunkManager $level, int $cx, int $cy, int $cz, Random $random): int{
                
                WellGenerator::generate($level, $cx, $cy, $cz);

                

                $buildings = [
                        ["iglesia_aldea", 1],
                        ["minicasa1",     4],
                        ["minicasa2",     2],
                        ["casat_aldea",   2],
                        ["herreria",      1],
                ];
                if($random->nextBoundedInt(100) < 20){
                        $buildings[] = ["herreria", 1];
                }
                if($random->nextBoundedInt(100) < 25){
                        $buildings[] = ["libreria_aldea", 1];
                }

                $queue = [];
                foreach($buildings as [$name, $count]){
                        for($i = 0; $i < $count; $i++){
                                $queue[] = $name;
                        }
                }

                for($i = count($queue) - 1; $i > 0; $i--){
                        $j = $random->nextBoundedInt($i + 1);
                        $tmp = $queue[$i]; $queue[$i] = $queue[$j]; $queue[$j] = $tmp;
                }

                $placed = 0;
                $placedPositions = []; 

                foreach($queue as $name){
                        
                        $bx = 0; $bz = 0; $by = -1; $rot = 0;
                        $found = false;

                        for($attempt = 0; $attempt < self::MAX_PLACEMENT_ATTEMPTS; $attempt++){
                                
                                $angle = $random->nextFloat() * 2.0 * M_PI;
                                $dist  = self::MIN_DIST_FROM_WELL
                                       + $random->nextBoundedInt(self::MAX_DIST_FROM_WELL - self::MIN_DIST_FROM_WELL + 1);
                                $bx = $cx + (int)round(cos($angle) * $dist);
                                $bz = $cz + (int)round(sin($angle) * $dist);

                                $collision = false;
                                foreach($placedPositions as [$px, $pz]){
                                        $ddx = $bx - $px;
                                        $ddz = $bz - $pz;
                                        if($ddx * $ddx + $ddz * $ddz < self::MIN_DIST_BETWEEN_STRUCTS * self::MIN_DIST_BETWEEN_STRUCTS){
                                                $collision = true;
                                                break;
                                        }
                                }
                                if($collision) continue;

                                $by = self::findSurfaceY($level, $bx, $bz, $cy);
                                if($by < 0) continue;

                                

                                
                                $rot = self::rotationToward($bx, $bz, $cx, $cz);

                                $found = true;
                                break;
                        }

                        if(!$found) continue; 

                        $struct = self::loadStructure($name);
                        if($struct === null){
                                continue;
                        }

                        
                        $struct->paste($level, $bx, $by, $bz, $rot, $random);

                        
                        
                        RoadGenerator::layRoadBetween($level, $cx, $cy, $cz, $bx, $by, $bz);

                        $placedPositions[] = [$bx, $bz];
                        $placed++;
                }

                
                
                FarmGenerator::generate($level, $cx, $cy, $cz, $random, $placedPositions);

                return $placed;
        }

        private static function rotationToward(int $sx, int $sz, int $tx, int $tz): int{
                $dx = $tx - $sx;
                $dz = $tz - $sz;
                
                if($dx === 0 && $dz === 0) return 0;
                $angle = atan2($dz, $dx); 
                $deg = rad2deg($angle);    
                if($deg < 0) $deg += 360;  
                
                $rot = (int)round($deg / 90.0) * 90;
                $rot %= 360;
                return $rot;
        }

        private function loadStructure(string $name){
                if(isset(self::$cache[$name])){
                        return self::$cache[$name];
                }
                $path = $this->structuresDir . $name . ".dat";
                $loader = new StructureLoader($path);
                if(!$loader->load()){
                        return self::$cache[$name] = null;
                }
                return self::$cache[$name] = $loader;
        }

        private static function findSurfaceY(ChunkManager $level, int $x, int $z, int $hintY): int{
                $waterish    = [Block::WATER, Block::STILL_WATER, Block::LAVA, Block::STILL_LAVA];
                $passthrough = [Block::AIR, Block::LEAVES, Block::LEAVES2, Block::TALL_GRASS, Block::SNOW_LAYER, Block::LOG, Block::WOOD2];
                $top = min(127, $hintY + 20);
                $bot = max(1,   $hintY - 20);
                for($y = $top; $y > $bot; --$y){
                        $here = $level->getBlockIdAt($x, $y, $z);
                        if(in_array($here, $passthrough, true)) continue;
                        if(in_array($here, $waterish,   true)) return -1;
                        return $y + 1;
                }
                return -1;
        }
}
