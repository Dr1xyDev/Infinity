<?php

namespace Infinity;

use pocketmine\event\level\ChunkPopulateEvent;
use pocketmine\event\Listener;
use pocketmine\level\Level;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\Random;
use Infinity\desert\DesertPyramidPopulator;
use Infinity\desert\DesertVillagePopulator;
use Infinity\populator\VillagePopulator;

class Structures extends PluginBase implements Listener{

        private $enabledWorlds = [];
        private $globalOptions = [];
        private $worldOptions = [];
        private $worldFeatures = [];
        private $populator = null;
        private $desertVillagePopulator = null;
        private $pyramidPopulator = null;
        private $structuresDir;

        const CURRENT_CONFIG_VERSION = 3;

        const STRUCTURE_FILES = [
                "casat_aldea.dat",
                "libreria_aldea.dat",
                "minicasa1.dat",
                "minicasa2.dat",
                "iglesia_aldea.dat",
                "herreria.dat",
                "loot_chest_herreria.json",
                "desert_iglesia.dat",
                "desert_mediumhouse.dat",
                "desert_mediumhouse2.dat",
                "desert_minihouse1.dat",
                "desert_minihouse2.dat",
                "loot_chest_desert_iglesia.json",
                "loot_chest_desert_mediumhouse.json",
                "desert_piramid.dat",
                "loot_chest_desert_piramid.json",
        ];

        public function onEnable(){
                $this->getLogger()->info("§9Cargando extension de estructuras...");
                $this->saveDefaultWorldConfig();
                $this->loadWorldConfig();
                $this->extractStructures();

                $this->structuresDir = $this->getDataFolder() . "structures/";
                $this->populator              = new VillagePopulator($this->structuresDir, $this);
                $this->desertVillagePopulator = new DesertVillagePopulator($this->structuresDir, $this);
                $this->pyramidPopulator       = new DesertPyramidPopulator($this->structuresDir, $this);

                $this->getServer()->getPluginManager()->registerEvents($this, $this);

                if(empty($this->enabledWorlds)){
                        $this->getLogger()->warning("No worlds enabled in world.yml");
                }else{
                        $this->getLogger()->info("Enabled for worlds: " . implode(", ", $this->enabledWorlds));
                }
        }

        public function onDisable(){
                $this->populator = null;
                $this->desertVillagePopulator = null;
                $this->pyramidPopulator = null;
        }

        private function saveDefaultWorldConfig(){
                $configFile = $this->getDataFolder() . "world.yml";
                if(!file_exists($configFile)){
                        $this->saveResource("world.yml");
                        return;
                }
                $this->migrateConfigIfNeeded($configFile);
        }

        private function migrateConfigIfNeeded(string $configFile){
                $oldConfig = new Config($configFile, Config::YAML);
                $oldVersion = (int)$oldConfig->get("config-version", 0);

                if($oldVersion >= self::CURRENT_CONFIG_VERSION){
                        return;
                }

                $backup = $configFile . ".bak.v" . $oldVersion;
                if(!file_exists($backup)){
                        @copy($configFile, $backup);
                }

                $oldWorlds = $oldConfig->get("worlds", []);
                $oldOptions = $oldConfig->get("options", []);
                if(!is_array($oldWorlds))    $oldWorlds = [];
                if(!is_array($oldOptions))   $oldOptions = [];

                $this->saveResource("world.yml", true);

                $newConfig = new Config($configFile, Config::YAML);
                if(!empty($oldWorlds)){
                        $newConfig->set("worlds", $oldWorlds);
                }

                if(isset($oldOptions["spawn-radius"]) && (int)$oldOptions["spawn-radius"] >= 100){
                        $newOptions = $newConfig->get("options", []);
                        $newOptions["spawn-radius"] = (int)$oldOptions["spawn-radius"];
                        $newConfig->set("options", $newOptions);
                }
                if(isset($oldOptions["target-count"]) && (int)$oldOptions["target-count"] >= 1){
                        $newOptions = $newConfig->get("options", []);
                        $newOptions["target-count"] = (int)$oldOptions["target-count"];
                        $newConfig->set("options", $newOptions);
                }
                $newConfig->save();

                $this->getLogger()->warning("world.yml migrated v" . $oldVersion . " -> v" . self::CURRENT_CONFIG_VERSION);
        }

        private function loadWorldConfig(){
                $configFile = $this->getDataFolder() . "world.yml";
                $config = new Config($configFile, Config::YAML);

                $defaults = [
                        "spawn-radius"          => 2000,
                        "target-count"          => 12,
                        "search-chunks"         => 0,
                        "min-land-fraction"     => 0.3,
                        "max-height-variation"  => 24,
                        "log-generation"        => false,
                        "villages"              => true,
                        "desert-villages"       => true,
                        "desert-pyramids"       => true,
                        "pyramid-target-count"  => 6,
                        "pyramid-min-distance"  => 200,
                ];
                $options = $config->get("options", []);
                if(!is_array($options)){
                        $options = [];
                }
                $this->globalOptions = array_merge($defaults, $options);

                $worlds = $config->get("worlds", []);
                if(!is_array($worlds)){
                        $worlds = [];
                }
                foreach($worlds as $name => $settings){
                        $name = (string)$name;
                        if($settings === true){
                                $this->enabledWorlds[] = $name;
                                $this->worldFeatures[$name] = [
                                        "villages"        => $this->globalOptions["villages"],
                                        "desert-villages" => $this->globalOptions["desert-villages"],
                                        "desert-pyramids" => $this->globalOptions["desert-pyramids"],
                                ];
                                continue;
                        }
                        if(is_array($settings) && isset($settings["enabled"]) && $settings["enabled"] === true){
                                $this->enabledWorlds[] = $name;
                                $this->worldOptions[$name] = $settings;
                                $this->worldFeatures[$name] = [
                                        "villages"        => isset($settings["villages"])
                                                ? (bool)$settings["villages"] : $this->globalOptions["villages"],
                                        "desert-villages" => isset($settings["desert-villages"])
                                                ? (bool)$settings["desert-villages"] : $this->globalOptions["desert-villages"],
                                        "desert-pyramids" => isset($settings["desert-pyramids"])
                                                ? (bool)$settings["desert-pyramids"] : $this->globalOptions["desert-pyramids"],
                                ];
                        }
                }
        }

        private function extractStructures(){
                $structDir = $this->getDataFolder() . "structures/";
                if(!is_dir($structDir)){
                        @mkdir($structDir, 0755, true);
                }
                foreach(self::STRUCTURE_FILES as $file){
                        $dest = $structDir . $file;
                        if(!file_exists($dest)){
                                $this->saveResource("structures/" . $file);
                        }
                }
        }

        public function getOptionsForWorld(string $worldName): array{
                if(isset($this->worldOptions[$worldName])){
                        return array_merge($this->globalOptions, $this->worldOptions[$worldName]);
                }
                return $this->globalOptions;
        }

        public function getFeaturesForWorld(string $worldName): array{
                if(isset($this->worldFeatures[$worldName])){
                        return $this->worldFeatures[$worldName];
                }
                return [
                        "villages"        => false,
                        "desert-villages" => false,
                        "desert-pyramids" => false,
                ];
        }

        public function isWorldEnabled(string $worldName): bool{
                return in_array($worldName, $this->enabledWorlds, true);
        }

        /**
         * @priority MONITOR
         * @ignoreCancelled true
         */
        public function onChunkPopulate(ChunkPopulateEvent $event){
                $level = $event->getLevel();
                $worldName = $level->getName();
                if(!$this->isWorldEnabled($worldName)){
                        return;
                }

                $chunk = $event->getChunk();
                $chunkX = $chunk->getX();
                $chunkZ = $chunk->getZ();

                $options  = $this->getOptionsForWorld($worldName);
                $features = $this->getFeaturesForWorld($worldName);

                if(!empty($features["villages"])){
                        $this->populator->configure($options);
                        $hash = VillagePopulator::chunkHash($level->getSeed(), $chunkX, $chunkZ);
                        $random = new Random($hash);
                        $this->populator->populate($level, $chunkX, $chunkZ, $random);
                }

                if(!empty($features["desert-villages"])){
                        $this->desertVillagePopulator->configure($options);
                        $hash = DesertVillagePopulator::chunkHash($level->getSeed(), $chunkX, $chunkZ);
                        $random = new Random($hash);
                        $this->desertVillagePopulator->populate($level, $chunkX, $chunkZ, $random);
                }

                if(!empty($features["desert-pyramids"])){
                        $this->pyramidPopulator->configure($options);
                        $hash = DesertPyramidPopulator::chunkHash($level->getSeed(), $chunkX, $chunkZ);
                        $random = new Random($hash);
                        $this->pyramidPopulator->populate($level, $chunkX, $chunkZ, $random);
                }
        }

        public function getLoggerSafe(): \pocketmine\plugin\PluginLogger{
                return $this->getLogger();
        }
}
