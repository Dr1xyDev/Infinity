<?php

namespace Infinity\desert;

use pocketmine\block\Block;
use pocketmine\level\ChunkManager;
use pocketmine\level\generator\populator\Populator;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\utils\Random;
use Infinity\structure\StructureLoader;
use Infinity\Structures;

class DesertPyramidPopulator extends Populator{

	public $spawnRadius = 2000;
	public $targetPyramidCount = 6;
	public $searchChunks = 0;
	public $minLandFraction = 0.3;
	public $maxHeightVariation = 24;
	public $logGeneration = false;
	public $minPyramidDistance = 200;

	const HALF_BURY_LAYERS = 11;

	const WATER_IDS = [
		Block::WATER, Block::STILL_WATER,
		Block::LAVA,  Block::STILL_LAVA,
	];

	private $spawn = null;
	private static $placedKeys = [];
	private static $structCache = null;
	private $structuresDir;
	private $plugin;

	public function __construct(string $structuresDir, Structures $plugin){
		$this->structuresDir = rtrim($structuresDir, "\\/") . "/";
		$this->plugin = $plugin;
	}

	public function configure(array $options){
		if(isset($options["spawn-radius"]))         $this->spawnRadius         = (int)$options["spawn-radius"];
		if(isset($options["pyramid-target-count"])) $this->targetPyramidCount  = (int)$options["pyramid-target-count"];
		if(isset($options["search-chunks"]))        $this->searchChunks        = (int)$options["search-chunks"];
		if(isset($options["min-land-fraction"]))    $this->minLandFraction     = (float)$options["min-land-fraction"];
		if(isset($options["max-height-variation"])) $this->maxHeightVariation  = (int)$options["max-height-variation"];
		if(isset($options["log-generation"]))       $this->logGeneration       = (bool)$options["log-generation"];
		if(isset($options["pyramid-min-distance"])) $this->minPyramidDistance  = (int)$options["pyramid-min-distance"];
	}

	public function populate(ChunkManager $level, $chunkX, $chunkZ, Random $random): void{
		$wx = ($chunkX << 4) + 8;
		$wz = ($chunkZ << 4) + 8;

		$spawn = $this->getSpawn($level);
		$dx = $wx - $spawn->x;
		$dz = $wz - $spawn->z;
		if($dx * $dx + $dz * $dz > $this->spawnRadius * $this->spawnRadius) return;

		$effectiveSearch = $this->searchChunks > 0
			? $this->searchChunks
			: (int)max(100, round(M_PI * $this->spawnRadius * $this->spawnRadius / 256.0));

		$probPerChunk = $this->targetPyramidCount / max(1, $effectiveSearch);
		$hash = self::chunkHash($level->getSeed(), $chunkX, $chunkZ);
		$roll = ($hash & 0xFFFFFF) / (float)0x1000000;
		if($roll >= $probPerChunk) return;

		$cy = self::findSurfaceY($level, $wx, $wz);
		if($cy < 0) return;

		if(!self::isDesertBiome($level, $wx, $cy, $wz)) return;

		$landCount = 0;
		$sampleCount = 0;
		$heights = [];
		for($ox = -8; $ox <= 8; $ox += 4){
			for($oz = -8; $oz <= 8; $oz += 4){
				$sx = $wx + $ox;
				$sz = $wz + $oz;
				$sy = self::findSurfaceY($level, $sx, $sz);
				if($sy < 0) continue;
				$sampleCount++;
				$block = $level->getBlockIdAt($sx, $sy - 1, $sz);
				if(!in_array($block, self::WATER_IDS, true)){
					$landCount++;
					$heights[] = $sy;
				}
			}
		}
		if($sampleCount === 0) return;
		if(($landCount / $sampleCount) < $this->minLandFraction) return;

		if(count($heights) > 0){
			if(max($heights) - min($heights) > $this->maxHeightVariation) return;
		}

		$key = self::areaKey($wx, $wz, $this->minPyramidDistance);
		if(isset(self::$placedKeys[$key])) return;

		for($ix = -1; $ix <= 1; $ix++){
			for($iz = -1; $iz <= 1; $iz++){
				self::$placedKeys[self::areaKey(
					$wx + $ix * $this->minPyramidDistance,
					$wz + $iz * $this->minPyramidDistance,
					$this->minPyramidDistance
				)] = true;
			}
		}

		$pyramidRandom = new Random($hash);
		$this->generatePyramid($level, $wx, $cy, $wz, $pyramidRandom);
		$this->logPyramid($wx, $cy, $wz);
	}

	public function generatePyramid(ChunkManager $level, int $cx, int $surfaceY, int $cz, Random $random): int{
		$struct = $this->loadStructure();
		if($struct === null) return 0;

		$originY = $surfaceY - self::HALF_BURY_LAYERS;
		if($originY < 1) $originY = 1;

		$rotation = [0, 90, 180, 270][$random->nextBoundedInt(4)];

		return $struct->paste($level, $cx, $originY, $cz, $rotation, $random);
	}

	private function loadStructure(): ?StructureLoader{
		if(self::$structCache !== null) return self::$structCache;
		$path = $this->structuresDir . "desert_piramid.dat";
		$loader = new StructureLoader($path);
		if(!$loader->load()) return null;
		return self::$structCache = $loader;
	}

	private static function isDesertBiome(ChunkManager $level, int $cx, int $cy, int $cz): bool{
		$surface = $level->getBlockIdAt($cx, $cy - 1, $cz);
		if($surface !== Block::SAND) return false;

		$below = $level->getBlockIdAt($cx, $cy - 2, $cz);
		return ($below === Block::SAND || $below === Block::SANDSTONE);
	}

	private function getSpawn(ChunkManager $level): Vector3{
		if($this->spawn !== null) return $this->spawn;
		foreach(["getSpawnLocation", "getSpawn"] as $method){
			if(method_exists($level, $method)){
				try{
					$s = $level->$method();
					if($s instanceof Vector3){
						return $this->spawn = $s;
					}
				}catch(\Throwable $e){}
			}
		}
		return $this->spawn = new Vector3(0, 128, 0);
	}

	private function logPyramid(int $x, int $y, int $z): void{
		if(!$this->logGeneration) return;
		try{
			$server = Server::getInstance();
			if($server === null) return;
			$server->getLogger()->notice("Desert pyramid generated at {$x} {$y} {$z}");
		}catch(\Throwable $e){}
	}

	public static function chunkHash($seed, int $chunkX, int $chunkZ): int{
		$h = (int)$seed ^ 0x1BADC0DE;
		$h ^= ($chunkX * 0x85EBCA6B);
		$h ^= ($chunkZ * 0xC2B2AE35);
		$h ^= ($h >> 13);
		$h = ($h * 0x27D4EB2F) & 0x7FFFFFFF;
		return $h;
	}

	private static function areaKey(int $x, int $z, int $cellSize): string{
		return sprintf("%d,%d",
			(int)floor($x / $cellSize),
			(int)floor($z / $cellSize)
		);
	}

	public static function findSurfaceY(ChunkManager $level, int $x, int $z): int{
		for($y = 127; $y > 0; --$y){
			$b = $level->getBlockIdAt($x, $y, $z);
			if($b === Block::AIR || $b === Block::LEAVES || $b === Block::LEAVES2
				|| $b === Block::TALL_GRASS || $b === Block::SNOW_LAYER
				|| $b === Block::WATER || $b === Block::STILL_WATER
				|| $b === Block::LAVA  || $b === Block::STILL_LAVA
				|| $b === Block::DEAD_BUSH){
				continue;
			}
			return $y + 1;
		}
		return -1;
	}
}
