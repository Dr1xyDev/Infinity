<?php

namespace Infinity\desert;

use pocketmine\block\Block;
use pocketmine\level\ChunkManager;
use pocketmine\utils\Random;

class DesertFarmGenerator{

        const HALF_X = 3;   
        const HALF_Z = 4;   

        const MIN_FARMS              = 3;
        const MAX_FARMS              = 6;
        const PAIR_CHANCE            = 80;   
        const MIN_DIST_FROM_WELL     = 14;
        const MAX_DIST_FROM_WELL     = 22;
        const MIN_DIST_BETWEEN_FARMS = 12;
        const MIN_DIST_TO_BUILDING   = 10;
        const MAX_PLACEMENT_ATTEMPTS = 35;
        const PAIR_OFFSET            = 11;

        const CROP_WHEAT    = 59;
        const CROP_CARROTS  = 141;
        const CROP_POTATOES = 142;

        private static $CROP_TYPES = [
                self::CROP_WHEAT,
                self::CROP_CARROTS,
                self::CROP_POTATOES,
        ];

        
        const BLOCK_RING     = Block::SANDSTONE;   
        const BLOCK_FARMLAND = Block::FARMLAND;    
        const BLOCK_WATER    = Block::STILL_WATER; 

        

        

        public static function generate(
                ChunkManager $level,
                int $cx, int $cy, int $cz,
                Random $random,
                array $buildingPos = []
        ): int {
                $targetFarms = self::MIN_FARMS
                             + $random->nextBoundedInt(self::MAX_FARMS - self::MIN_FARMS + 1);

                $placed      = 0;
                $farmCenters = [];

                while($placed < $targetFarms){
                        $wantPair = ($random->nextBoundedInt(100) < self::PAIR_CHANCE)
                                 && ($placed + 1 < $targetFarms);

                        if($wantPair){
                                $n = self::placePair($level, $cx, $cy, $cz, $random, $buildingPos, $farmCenters);
                                if($n > 0){
                                        $placed += $n;
                                        continue;
                                }
                        }

                        $pos = self::findPosition($cx, $cz, $random, $buildingPos, $farmCenters);
                        if($pos === null) break;
                        [$fx, $fz] = $pos;

                        $fy = self::flatSurfaceY($level, $fx, $fz, $cy);
                        if($fy < 0) break;

                        self::placeFarm($level, $fx, $fy, $fz, $random);
                        $farmCenters[] = [$fx, $fz];
                        $placed++;
                }

                return $placed;
        }

        

        private static function placePair(
                ChunkManager $level,
                int $cx, int $cy, int $cz,
                Random $random,
                array $buildingPos,
                array &$farmCenters
        ): int {
                $pos1 = self::findPosition($cx, $cz, $random, $buildingPos, $farmCenters);
                if($pos1 === null) return 0;
                [$f1x, $f1z] = $pos1;

                $f1y = self::flatSurfaceY($level, $f1x, $f1z, $cy);
                if($f1y < 0) return 0;

                $angle   = atan2($f1z - $cz, $f1x - $cx);
                $allUsed = array_merge($buildingPos, $farmCenters);

                foreach([$angle + M_PI / 2, $angle - M_PI / 2] as $perp){
                        $f2x = $f1x + (int)round(cos($perp) * self::PAIR_OFFSET);
                        $f2z = $f1z + (int)round(sin($perp) * self::PAIR_OFFSET);

                        $usedWithF1 = array_merge($allUsed, [[$f1x, $f1z]]);
                        if(!self::positionIsValid($f2x, $f2z, $cx, $cz, $buildingPos, $usedWithF1)) continue;

                        $f2y = self::flatSurfaceY($level, $f2x, $f2z, $cy);
                        if($f2y < 0) continue;

                        self::placeFarm($level, $f1x, $f1y, $f1z, $random);
                        $farmCenters[] = [$f1x, $f1z];
                        self::placeFarm($level, $f2x, $f2y, $f2z, $random);
                        $farmCenters[] = [$f2x, $f2z];
                        return 2;
                }

                self::placeFarm($level, $f1x, $f1y, $f1z, $random);
                $farmCenters[] = [$f1x, $f1z];
                return 1;
        }

        

        private static function findPosition(
                int $cx, int $cz,
                Random $random,
                array $buildingPos,
                array $farmCenters
        ): ?array {
                $allOccupied = array_merge($buildingPos, $farmCenters);

                for($i = 0; $i < self::MAX_PLACEMENT_ATTEMPTS; $i++){
                        $angle = $random->nextFloat() * 2.0 * M_PI;
                        $dist  = self::MIN_DIST_FROM_WELL
                               + $random->nextBoundedInt(self::MAX_DIST_FROM_WELL - self::MIN_DIST_FROM_WELL + 1);
                        $fx = $cx + (int)round(cos($angle) * $dist);
                        $fz = $cz + (int)round(sin($angle) * $dist);

                        if(self::positionIsValid($fx, $fz, $cx, $cz, $buildingPos, $allOccupied)){
                                return [$fx, $fz];
                        }
                }
                return null;
        }

        private static function positionIsValid(
                int $fx, int $fz,
                int $cx, int $cz,
                array $buildingPos,
                array $allOccupied
        ): bool {
                $dwx = $fx - $cx; $dwz = $fz - $cz;
                if($dwx * $dwx + $dwz * $dwz < self::MIN_DIST_FROM_WELL * self::MIN_DIST_FROM_WELL) return false;

                foreach($buildingPos as [$px, $pz]){
                        $dx = $fx - $px; $dz = $fz - $pz;
                        if($dx * $dx + $dz * $dz < self::MIN_DIST_TO_BUILDING * self::MIN_DIST_TO_BUILDING) return false;
                }
                foreach($allOccupied as [$px, $pz]){
                        $dx = $fx - $px; $dz = $fz - $pz;
                        if($dx * $dx + $dz * $dz < self::MIN_DIST_BETWEEN_FARMS * self::MIN_DIST_BETWEEN_FARMS) return false;
                }
                return true;
        }

        

        private static function flatSurfaceY(ChunkManager $level, int $cx, int $cz, int $hintY): int{
                $minY  = PHP_INT_MAX;
                $found = 0;

                for($dx = -self::HALF_X; $dx <= self::HALF_X; $dx++){
                        for($dz = -self::HALF_Z; $dz <= self::HALF_Z; $dz++){
                                $y = self::surfaceAt($level, $cx + $dx, $cz + $dz, $hintY);
                                if($y < 0) continue;
                                $found++;
                                if($y < $minY) $minY = $y;
                        }
                }

                $total = (self::HALF_X * 2 + 1) * (self::HALF_Z * 2 + 1); 
                if($found < (int)($total * 0.5)) return -1;
                return ($minY === PHP_INT_MAX) ? -1 : $minY;
        }

        private static function surfaceAt(ChunkManager $level, int $x, int $z, int $hintY): int{
                for($dy = 0; $dy <= 8; $dy++){
                        foreach([0, -$dy, $dy] as $off){
                                $y = $hintY + $off;
                                if($y < 2 || $y > 125) continue;

                                $here  = $level->getBlockIdAt($x, $y - 1, $z);
                                $above = $level->getBlockIdAt($x, $y,     $z);

                                if(in_array($here, [
                                        Block::AIR, Block::WATER, Block::STILL_WATER,
                                        Block::LAVA, Block::STILL_LAVA,
                                        Block::LEAVES, Block::LEAVES2,
                                        Block::TALL_GRASS, Block::SNOW_LAYER,
                                ], true)) continue;

                                if(!in_array($above, [
                                        Block::AIR, Block::TALL_GRASS, Block::SNOW_LAYER,
                                        Block::DEAD_BUSH, Block::DOUBLE_PLANT,
                                ], true)) continue;

                                return $y;
                        }
                }
                return -1;
        }

        

        

        public static function placeFarm(
                ChunkManager $level,
                int $cx, int $cy, int $cz,
                Random $random
        ): void {
                $cropLeft  = self::$CROP_TYPES[$random->nextBoundedInt(count(self::$CROP_TYPES))];
                $cropRight = self::$CROP_TYPES[$random->nextBoundedInt(count(self::$CROP_TYPES))];

                for($dx = -self::HALF_X; $dx <= self::HALF_X; $dx++){
                        for($dz = -self::HALF_Z; $dz <= self::HALF_Z; $dz++){
                                $x = $cx + $dx;
                                $z = $cz + $dz;

                                $isRing = ($dx === -self::HALF_X || $dx === self::HALF_X
                                        || $dz === -self::HALF_Z || $dz === self::HALF_Z);

                                $supportId = $level->getBlockIdAt($x, $cy - 1, $z);
                                if(in_array($supportId, [Block::AIR, Block::TALL_GRASS, Block::SNOW_LAYER], true)){
                                        $level->setBlockIdAt($x,  $cy - 1, $z, Block::SAND);
                                        $level->setBlockDataAt($x, $cy - 1, $z, 0);
                                }

                                $nonSolidAbove = [
                                        Block::AIR, Block::TALL_GRASS, Block::DEAD_BUSH,
                                        Block::SNOW_LAYER, Block::DOUBLE_PLANT,
                                        Block::SAPLING, Block::RED_FLOWER, Block::DANDELION,
                                ];
                                for($clearY = $cy + 1; $clearY <= $cy + 4; $clearY++){
                                        if($clearY > 127) break;
                                        if(!in_array($level->getBlockIdAt($x, $clearY, $z), $nonSolidAbove, true)){
                                                $level->setBlockIdAt($x,  $clearY, $z, Block::AIR);
                                                $level->setBlockDataAt($x, $clearY, $z, 0);
                                        }
                                }

                                if($isRing){
                                        
                                        $level->setBlockIdAt($x,  $cy, $z, self::BLOCK_RING);
                                        $level->setBlockDataAt($x, $cy, $z, 0);

                                }elseif($dx === 0){
                                        
                                        $level->setBlockIdAt($x,  $cy, $z, self::BLOCK_WATER);
                                        $level->setBlockDataAt($x, $cy, $z, 0);

                                }else{
                                        
                                        $level->setBlockIdAt($x,  $cy, $z, self::BLOCK_FARMLAND);
                                        $level->setBlockDataAt($x, $cy, $z, 7);

                                        $crop  = ($dx < 0) ? $cropLeft : $cropRight;
                                        $stage = $random->nextBoundedInt(8);
                                        $level->setBlockIdAt($x,  $cy + 1, $z, $crop);
                                        $level->setBlockDataAt($x, $cy + 1, $z, $stage);
                                }
                        }
                }
        }

        public static function getRadius(): int{
                return max(self::HALF_X, self::HALF_Z) + 1;
        }
}
