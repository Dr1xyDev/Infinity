<?php

namespace Infinity\structure;

use pocketmine\block\Block;
use pocketmine\level\ChunkManager;
use pocketmine\math\Vector3;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\tile\Tile;

class StructureLoader{

        private $data = null;

        private $path;

        private $lootData = null;

        private $lootLoaded = false;

        private $boundsCache = null;

        public function __construct(string $path){
                $this->path = $path;
        }

        public function load(): bool{
                if(!is_file($this->path)) return false;
                $raw = @file_get_contents($this->path);
                if($raw === false) return false;
                $data = json_decode($raw, true);
                if(!is_array($data) || !isset($data["blocks"]) || !is_array($data["blocks"])) return false;
                $this->data = $data;
                return true;
        }

        public function loadLoot(): bool{
                if($this->lootLoaded) return $this->lootData !== null;
                $this->lootLoaded = true;
                if($this->data === null) return false;
                $structName = $this->data["name"] ?? basename($this->path, ".dat");
                $lootPath   = dirname($this->path) . "/loot_chest_" . $structName . ".json";
                if(!is_file($lootPath)) return false;
                $raw  = @file_get_contents($lootPath);
                if($raw === false) return false;
                $loot = json_decode($raw, true);
                if(!is_array($loot) || !isset($loot["items"]) || !is_array($loot["items"])) return false;
                $this->lootData = $loot;
                return true;
        }

        public function getData(){ return $this->data; }
        public function getLootData(){ return $this->lootData; }
        public function getSize(){ return $this->data["size"] ?? null; }

        public function getBounds(): array{
                if($this->boundsCache !== null) return $this->boundsCache;
                if($this->data === null) return [];
                $xs = []; $ys = []; $zs = [];
                foreach($this->data["blocks"] as $b){
                        $xs[] = $b["x"]; $ys[] = $b["y"]; $zs[] = $b["z"];
                }
                $this->boundsCache = [
                        "minX" => min($xs), "maxX" => max($xs),
                        "minY" => min($ys), "maxY" => max($ys),
                        "minZ" => min($zs), "maxZ" => max($zs),
                ];
                return $this->boundsCache;
        }

        public function paste(ChunkManager $level, int $originX, int $originY, int $originZ, int $rotation = 0, $random = null): int{
                if($this->data === null) return 0;
                $rotation = (($rotation % 360) + 360) % 360;
                if(!$this->lootLoaded) $this->loadLoot();

                $this->clearTreesInArea($level, $originX, $originY, $originZ, $rotation);
                $placed = $this->placeBlocks($level, $originX, $originY, $originZ, $rotation);
                $this->fillFoundation($level, $originX, $originY, $originZ, $rotation);
                $this->pasteTiles($level, $originX, $originY, $originZ, $rotation, $random);
                return $placed;
        }

        private function placeBlocks(ChunkManager $level, int $originX, int $originY, int $originZ, int $rotation): int{
                $placed = 0;
                foreach($this->data["blocks"] as $b){
                        $id   = (int)$b["id"];
                        $meta = isset($b["meta"]) ? (int)$b["meta"] : 0;
                        if($id === Block::AIR) continue;
                        $rx = (int)$b["x"]; $ry = (int)$b["y"]; $rz = (int)$b["z"];
                        [$rx, $rz] = self::rotateOffset($rx, $rz, $rotation);
                        if($rotation !== 0) $meta = self::rotateMeta($id, $meta, $rotation);
                        $tx = $originX + $rx; $ty = $originY + $ry; $tz = $originZ + $rz;
                        if($ty < 0 || $ty >= 128) continue;
                        $level->setBlockIdAt($tx, $ty, $tz, $id);
                        $level->setBlockDataAt($tx, $ty, $tz, $meta & 0x0f);
                        $placed++;
                }
                return $placed;
        }

        private function clearTreesInArea(ChunkManager $level, int $originX, int $originY, int $originZ, int $rotation): void{
                $bounds = $this->getBounds();
                if(empty($bounds)) return;
                $treeIds = [Block::LOG, Block::WOOD2, Block::LEAVES, Block::LEAVES2];
                for($rx = $bounds["minX"]; $rx <= $bounds["maxX"]; $rx++){
                        for($rz = $bounds["minZ"]; $rz <= $bounds["maxZ"]; $rz++){
                                [$wx_off, $wz_off] = self::rotateOffset($rx, $rz, $rotation);
                                $wx = $originX + $wx_off; $wz = $originZ + $wz_off;
                                for($ry = 0; $ry <= 15; $ry++){
                                        $wy = $originY + $ry;
                                        if($wy < 0 || $wy > 127) continue;
                                        if(in_array($level->getBlockIdAt($wx, $wy, $wz), $treeIds, true)){
                                                $level->setBlockIdAt($wx, $wy, $wz, Block::AIR);
                                                $level->setBlockDataAt($wx, $wy, $wz, 0);
                                        }
                                }
                        }
                }
        }

        private function fillFoundation(ChunkManager $level, int $originX, int $originY, int $originZ, int $rotation): void{
                $bounds = $this->getBounds();
                if(empty($bounds)) return;
                $fillIds = [Block::AIR, Block::WATER, Block::STILL_WATER, Block::LAVA, Block::STILL_LAVA];
                foreach($this->getFloorColumns() as [$rx, $rz]){
                        [$wx_off, $wz_off] = self::rotateOffset($rx, $rz, $rotation);
                        $wx = $originX + $wx_off; $wz = $originZ + $wz_off;
                        for($dy = 1; $dy <= 4; $dy++){
                                $wy = $originY - $dy;
                                if($wy < 0) break;
                                if(in_array($level->getBlockIdAt($wx, $wy, $wz), $fillIds, true)){
                                        $level->setBlockIdAt($wx, $wy, $wz, ($dy === 1) ? Block::GRASS : Block::DIRT);
                                        $level->setBlockDataAt($wx, $wy, $wz, 0);
                                }else break;
                        }
                }
        }

        private function getFloorColumns(): array{
                $cols = []; $seen = [];
                foreach($this->data["blocks"] as $b){
                        if((int)$b["y"] === 0){
                                $key = $b["x"] . "," . $b["z"];
                                if(!isset($seen[$key])){ $seen[$key] = true; $cols[] = [(int)$b["x"], (int)$b["z"]]; }
                        }
                }
                return $cols;
        }

        private function pasteTiles(ChunkManager $level, int $originX, int $originY, int $originZ, int $rotation, $random = null): void{
                if(!isset($this->data["tiles"]) || !is_array($this->data["tiles"])) return;

                foreach($this->data["tiles"] as $tile){
                        if(!isset($tile["type"]) || $tile["type"] !== "Chest") continue;

                        $rx = (int)($tile["x"] ?? 0);
                        $ry = (int)($tile["y"] ?? 0);
                        $rz = (int)($tile["z"] ?? 0);
                        [$wx_off, $wz_off] = self::rotateOffset($rx, $rz, $rotation);
                        $tx = $originX + $wx_off; $ty = $originY + $ry; $tz = $originZ + $wz_off;
                        if($ty < 0 || $ty >= 128) continue;

                        $facing = self::rotateChestFacing((int)($tile["facing"] ?? 2), $rotation);
                        $level->setBlockIdAt($tx, $ty, $tz, Block::CHEST);
                        $level->setBlockDataAt($tx, $ty, $tz, $facing);

                        $useLoot = !empty($tile["loot_json"]) && $this->lootData !== null;
                        $itemsList = $useLoot
                                ? $this->buildLootItems($random)
                                : $this->buildSavedItems($tile["items"] ?? []);

                        $nbt = new CompoundTag("", [
                                "id"    => new StringTag("id", Tile::CHEST),
                                "x"     => new IntTag("x", $tx),
                                "y"     => new IntTag("y", $ty),
                                "z"     => new IntTag("z", $tz),
                                "Items" => new ListTag("Items", $itemsList),
                        ]);
                        $nbt->Items->setTagType(NBT::TAG_Compound);

                        $chunk = $level->getChunk($tx >> 4, $tz >> 4);
                        if($chunk === null) continue;

                        

                        if(method_exists($chunk, 'getProvider')
                                && $chunk->getProvider() !== null
                                && method_exists($chunk->getProvider(), 'getLevel')
                                && ($lv = $chunk->getProvider()->getLevel()) !== null
                        ){
                                $existing = $lv->getTile(new Vector3($tx, $ty, $tz));
                                if($existing !== null) $existing->close();
                                Tile::createTile("Chest", $chunk, $nbt);
                        }

                }
        }

        private function buildSavedItems(array $savedItems): array{
                $list = [];
                foreach($savedItems as $item){
                        $id    = (int)($item["id"]    ?? 0);
                        $count = (int)($item["count"] ?? 1);
                        if($id === 0 || $count <= 0) continue;
                        $list[] = new CompoundTag("", [
                                "id"     => new ShortTag("id",     $id),
                                "Count"  => new ByteTag("Count",   $count),
                                "Damage" => new ShortTag("Damage", (int)($item["meta"] ?? 0)),
                                "Slot"   => new ByteTag("Slot",    (int)($item["slot"] ?? 0)),
                        ]);
                }
                return $list;
        }

        private function buildLootItems($random): array{
                $loot     = $this->lootData;
                $pool     = $loot["items"];
                $minSlots = max(0,  (int)($loot["min_slots"] ?? 3));
                $maxSlots = min(27, (int)($loot["max_slots"] ?? 9));
                if($maxSlots < $minSlots) $maxSlots = $minSlots;

                if($random !== null){
                        $range   = $maxSlots - $minSlots;
                        $numFill = $minSlots + ($range > 0 ? $random->nextBoundedInt($range + 1) : 0);
                }else{
                        $numFill = (int)(($minSlots + $maxSlots) / 2);
                }

                if($numFill <= 0 || count($pool) === 0) return [];

                $slots = range(0, 26);
                if($random !== null){
                        for($i = 26; $i > 0; $i--){
                                $j = $random->nextBoundedInt($i + 1);
                                [$slots[$i], $slots[$j]] = [$slots[$j], $slots[$i]];
                        }
                }else{
                        shuffle($slots);
                }

                $list = [];
                for($i = 0; $i < $numFill; $i++){
                        $entry = ($random !== null)
                                ? $pool[$random->nextBoundedInt(count($pool))]
                                : $pool[array_rand($pool)];

                        $id   = (int)($entry["id"]        ?? 0);
                        $meta = (int)($entry["meta"]      ?? 0);
                        $minC = max(1, (int)($entry["min_count"] ?? 1));
                        $maxC = max($minC, (int)($entry["max_count"] ?? $minC));
                        if($id === 0) continue;

                        $range = $maxC - $minC;
                        $count = ($random !== null)
                                ? $minC + ($range > 0 ? $random->nextBoundedInt($range + 1) : 0)
                                : (int)(($minC + $maxC) / 2);

                        $list[] = new CompoundTag("", [
                                "id"     => new ShortTag("id",     $id),
                                "Count"  => new ByteTag("Count",   $count),
                                "Damage" => new ShortTag("Damage",  $meta),
                                "Slot"   => new ByteTag("Slot",    $slots[$i]),
                        ]);
                }
                return $list;
        }

        private static function rotateOffset(int $dx, int $dz, int $rotation): array{
                switch($rotation){
                        case 90:  return [-$dz,  $dx];
                        case 180: return [-$dx, -$dz];
                        case 270: return [ $dz, -$dx];
                        default:  return [ $dx,  $dz];
                }
        }

        private static function rotateChestFacing(int $facing, int $rotation): int{
                if($facing < 2 || $facing > 5) return $facing;
                $map   = [2 => 4, 4 => 3, 3 => 5, 5 => 2];
                $steps = (($rotation / 90) % 4 + 4) % 4;
                for($i = 0; $i < $steps; $i++) $facing = $map[$facing] ?? $facing;
                return $facing;
        }

        public function getBlockAt(int $rx, int $ry, int $rz): ?array{
                if($this->data === null) return null;
                foreach($this->data["blocks"] as $b){
                        if((int)$b["x"] === $rx && (int)$b["y"] === $ry && (int)$b["z"] === $rz)
                                return ["id" => (int)$b["id"], "meta" => (int)($b["meta"] ?? 0)];
                }
                return null;
        }

        public static function rotateMeta(int $id, int $meta, int $angle): int{
                $steps = ($angle / 90) & 3;
                if($steps === 0) return $meta;

                $stairIds = [53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180];
                if(in_array($id, $stairIds, true)){
                        $facing = $meta & 0x03; $upsideDown = $meta & 0x04;
                        $m = [0 => 2, 2 => 1, 1 => 3, 3 => 0];
                        for($i = 0; $i < $steps; $i++) $facing = $m[$facing] ?? $facing;
                        return $facing | $upsideDown;
                }

                $doorIds = [64, 71, 193, 194, 195, 196, 197];
                if(in_array($id, $doorIds, true)){
                        if(($meta & 0x08) !== 0) return $meta;
                        $facing = ($meta & 0x03 + $steps) & 0x03;
                        return $facing | ($meta & ~0x03);
                }

                if($id === 96 || $id === 167){
                        return (($meta & 0x03 + $steps) & 0x03) | ($meta & ~0x03);
                }

                $fenceGateIds = [107, 183, 184, 185, 186, 187];
                if(in_array($id, $fenceGateIds, true)){
                        return (($meta & 0x03 + $steps) & 0x03) | ($meta & ~0x03);
                }

                if($id === 50 || $id === 75 || $id === 76){
                        if($meta >= 1 && $meta <= 4){
                                $m = [1 => 4, 4 => 2, 2 => 3, 3 => 1];
                                for($i = 0; $i < $steps; $i++) $meta = $m[$meta] ?? $meta;
                        }
                        return $meta;
                }

                $facing2to5Ids = [65, 23, 54, 61, 62, 29, 33, 25, 130, 146, 158, 84, 63];
                if(in_array($id, $facing2to5Ids, true)){
                        if($meta >= 2 && $meta <= 5){
                                $m = [2 => 4, 4 => 3, 3 => 5, 5 => 2];
                                for($i = 0; $i < $steps; $i++) $meta = $m[$meta] ?? $meta;
                                return $meta;
                        }
                        return $meta;
                }

                return $meta;
        }
}
