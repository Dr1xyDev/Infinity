<?php

namespace Infinity\generator;

use pocketmine\block\Block;
use pocketmine\level\ChunkManager;

class RoadGenerator{

        const SKIP_IDS = [
                Block::WATER, Block::STILL_WATER,
                Block::LAVA,  Block::STILL_LAVA,
                Block::COBBLESTONE, Block::PLANKS, Block::WOOD,
                Block::BRICKS, Block::STONE_BRICKS, Block::SANDSTONE,
                Block::GLASS, Block::GLASS_PANE, Block::FENCE,
                Block::COBBLESTONE_WALL,
                Block::WOOD_DOOR_BLOCK, Block::IRON_DOOR_BLOCK,
                Block::SPRUCE_DOOR_BLOCK, Block::BIRCH_DOOR_BLOCK,
                Block::JUNGLE_DOOR_BLOCK, Block::ACACIA_DOOR_BLOCK, Block::DARK_OAK_DOOR_BLOCK,
                Block::FENCE_GATE,
        ];

        public static function layRoadBetween(ChunkManager $level, int $x1, int $y1, int $z1, int $x2, int $y2, int $z2){
                
                $stepX = $x2 > $x1 ? 1 : -1;
                for($x = $x1; $x !== $x2 + $stepX; $x += $stepX){

                        self::placePathAt($level, $x, $z1,     $y1);
                        self::placePathAt($level, $x, $z1 + 1, $y1);
                }
                
                $stepZ = $z2 > $z1 ? 1 : -1;
                for($z = $z1; $z !== $z2 + $stepZ; $z += $stepZ){
                        self::placePathAt($level, $x2,     $z, $y2);
                        self::placePathAt($level, $x2 + 1, $z, $y2);
                }
        }

        private static function placePathAt(ChunkManager $level, int $x, int $z, int $hintY){
                
                $surfaceY = self::findSurfaceY($level, $x, $z, $hintY);
                if($surfaceY < 0 || $surfaceY >= 128) return;

                $existingId = $level->getBlockIdAt($x, $surfaceY, $z);
                if(in_array($existingId, self::SKIP_IDS, true)) return;

                $level->setBlockIdAt($x, $surfaceY, $z, Block::GRASS_PATH);
                $level->setBlockDataAt($x, $surfaceY, $z, 0);

                if($surfaceY + 1 < 128){
                        $above = $level->getBlockIdAt($x, $surfaceY + 1, $z);
                        if($above === Block::TALL_GRASS
                                || $above === Block::DANDELION
                                || $above === Block::POPPY
                                || $above === Block::SNOW_LAYER
                                || $above === Block::RED_FLOWER){
                                $level->setBlockIdAt($x, $surfaceY + 1, $z, Block::AIR);
                        }
                }
        }

        private static function findSurfaceY(ChunkManager $level, int $x, int $z, int $hintY): int{
                $start = $hintY + 6;
                if($start > 127) $start = 127;
                $end = $hintY - 6;
                if($end < 0) $end = 0;

                for($y = $start; $y >= $end; --$y){
                        $here  = $level->getBlockIdAt($x, $y, $z);
                        
                        if(in_array($here, [
                                Block::AIR, Block::WATER, Block::STILL_WATER,
                                Block::LAVA, Block::STILL_LAVA,
                                Block::LEAVES, Block::LEAVES2,
                                Block::TALL_GRASS, Block::SNOW_LAYER,
                                Block::LOG, Block::WOOD2,
                                Block::DANDELION, Block::POPPY,
                                Block::RED_FLOWER,
                        ], true)){
                                continue;
                        }
                        
                        if($y + 1 < 128){
                                $above = $level->getBlockIdAt($x, $y + 1, $z);
                                if($above === Block::AIR
                                        || $above === Block::TALL_GRASS
                                        || $above === Block::SNOW_LAYER
                                        || $above === Block::DANDELION
                                        || $above === Block::POPPY
                                        || $above === Block::RED_FLOWER){
                                        return $y; 
                                }
                        }else{
                                
                                return $y;
                        }
                }
                return -1;
        }
}
