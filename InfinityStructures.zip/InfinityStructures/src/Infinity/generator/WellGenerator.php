<?php

namespace Infinity\generator;

use pocketmine\block\Block;
use pocketmine\level\ChunkManager;

class WellGenerator{

        public static function generate(ChunkManager $level, int $cx, int $cy, int $cz){

                
                $corners = [[-2, -2], [-2, 1], [1, -2], [1, 1]];

                for($dx = -2; $dx <= 1; $dx++){
                        for($dz = -2; $dz <= 1; $dz++){
                                $x = $cx + $dx;
                                $z = $cz + $dz;
                                $level->setBlockIdAt($x, $cy - 1, $z, Block::COBBLESTONE);
                                $level->setBlockDataAt($x, $cy - 1, $z, 0);
                        }
                }

                for($dx = -2; $dx <= 1; $dx++){
                        for($dz = -2; $dz <= 1; $dz++){
                                $x = $cx + $dx;
                                $z = $cz + $dz;
                                if($dx >= -1 && $dx <= 0 && $dz >= -1 && $dz <= 0){
                                        
                                        $level->setBlockIdAt($x, $cy, $z, Block::STILL_WATER);
                                        $level->setBlockDataAt($x, $cy, $z, 0);
                                }else{
                                        
                                        $level->setBlockIdAt($x, $cy, $z, Block::COBBLESTONE);
                                        $level->setBlockDataAt($x, $cy, $z, 0);
                                }
                        }
                }

                for($dx = -2; $dx <= 1; $dx++){
                        for($dz = -2; $dz <= 1; $dz++){
                                $x = $cx + $dx;
                                $z = $cz + $dz;
                                if($dx >= -1 && $dx <= 0 && $dz >= -1 && $dz <= 0){
                                        
                                        $level->setBlockIdAt($x, $cy + 1, $z, Block::AIR);
                                        $level->setBlockDataAt($x, $cy + 1, $z, 0);
                                }else{
                                        
                                        $level->setBlockIdAt($x, $cy + 1, $z, Block::COBBLESTONE);
                                        $level->setBlockDataAt($x, $cy + 1, $z, 0);
                                }
                        }
                }

                
                foreach($corners as [$dx, $dz]){
                        $x = $cx + $dx;
                        $z = $cz + $dz;
                        for($y = $cy + 2; $y <= $cy + 3; $y++){
                                $level->setBlockIdAt($x, $y, $z, Block::FENCE);
                                $level->setBlockDataAt($x, $y, $z, 0);
                        }
                }

                for($dx = -2; $dx <= 1; $dx++){
                        for($dz = -2; $dz <= 1; $dz++){
                                
                                $isCorner = false;
                                foreach($corners as [$cdx, $cdz]){
                                        if($dx === $cdx && $dz === $cdz){
                                                $isCorner = true;
                                                break;
                                        }
                                }
                                if($isCorner){
                                        continue;
                                }
                                $x = $cx + $dx;
                                $z = $cz + $dz;
                                for($y = $cy + 2; $y <= $cy + 3; $y++){
                                        $level->setBlockIdAt($x, $y, $z, Block::AIR);
                                        $level->setBlockDataAt($x, $y, $z, 0);
                                }
                        }
                }

                
                for($dx = -2; $dx <= 1; $dx++){
                        for($dz = -2; $dz <= 1; $dz++){
                                $x = $cx + $dx;
                                $z = $cz + $dz;
                                $level->setBlockIdAt($x, $cy + 4, $z, Block::COBBLESTONE);
                                $level->setBlockDataAt($x, $cy + 4, $z, 0);
                        }
                }
        }
}
